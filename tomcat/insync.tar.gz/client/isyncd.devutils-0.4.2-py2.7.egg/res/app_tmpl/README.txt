%(package_name)s
============

%(description)s


Platform
--------

%(platform)s
Python 2.6

