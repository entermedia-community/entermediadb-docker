cd /usr/share/entermediadb/resin 
#./configure --enable-64bit --prefix=/usr/share/entermediadb/resin
#make
#make install

